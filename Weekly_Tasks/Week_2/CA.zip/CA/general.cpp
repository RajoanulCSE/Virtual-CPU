#include <iostream>
#include <vector>

class Registers {
private:
    std::vector<int> reg;

public:
    Registers(int size) : reg(size, 0) {}

    void write(int index, int value) {
        if (index >= 0 && index < reg.size()) {
            reg[index] = value;
        } else {
            std::cerr << "Error: Invalid register index!" << std::endl;
        }
    }

    int read(int index) {
        if (index >= 0 && index < reg.size()) {
            return reg[index];
        } else {
            std::cerr << "Error: Invalid register index!" << std::endl;
            return -1;
        }
    }

    void display() {
        for (size_t i = 0; i < reg.size(); i++) {
            std::cout << "Register[" << i << "] = " << reg[i] << std::endl;
        }
    }
};

int main() {
    Registers regs(4); // Create 4 general-purpose registers
    regs.write(0, 10);
    regs.write(1, 20);
    regs.write(2, 30);
    regs.display();
    std::cout << "Read Register[1]: " << regs.read(1) << std::endl;
    return 0;
}