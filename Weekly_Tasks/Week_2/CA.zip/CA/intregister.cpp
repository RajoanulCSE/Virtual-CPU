#include <iostream>

class CPU {
private:
    int programCounter;
    int instructionRegister;

public:
    CPU() : programCounter(0), instructionRegister(0) {}

    void fetchInstruction(int instruction) {
        instructionRegister = instruction;
        std::cout << "Fetched Instruction: " << instruction << std::endl;
    }

    void incrementProgramCounter() {
        programCounter++;
    }

    int getProgramCounter() {
        return programCounter;
    }

    int getInstructionRegister() {
        return instructionRegister;
    }
};

int main() {
    CPU cpu;

    // Simulating instructions
    cpu.fetchInstruction(101); // Fetch an instruction
    std::cout << "Program Counter: " << cpu.getProgramCounter() << std::endl;

    cpu.incrementProgramCounter(); // Increment PC
    cpu.fetchInstruction(102);
    std::cout << "Program Counter: " << cpu.getProgramCounter() << std::endl;

    return 0;
}