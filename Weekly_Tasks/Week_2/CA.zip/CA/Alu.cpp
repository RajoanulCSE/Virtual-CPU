#include <iostream>

class ALU {
public:
    int add(int a, int b) {
        return a + b;
    }

    int subtract(int a, int b) {
        return a - b;
    }

    int multiply(int a, int b) {
        return a * b;
    }

    int divide(int a, int b) {
        if (b != 0) return a / b;
        std::cerr << "Error: Division by zero!" << std::endl;
        return 0;
    }

    bool andOp(bool a, bool b) {
        return a && b;
    }

    bool orOp(bool a, bool b) {
        return a || b;
    }

    bool notOp(bool a) {
        return !a;
    }
};

int main() {
    ALU alu;
    std::cout << "Addition: " << alu.add(10, 5) << std::endl;
    std::cout << "Subtraction: " << alu.subtract(10, 5) << std::endl;
    std::cout << "Multiplication: " << alu.multiply(10, 5) << std::endl;
    std::cout << "Division: " << alu.divide(10, 5) << std::endl;
    std::cout << "AND: " << alu.andOp(true, false) << std::endl;
    std::cout << "OR: " << alu.orOp(true, false) << std::endl;
    std::cout << "NOT: " << alu.notOp(true) << std::endl;
    return 0;
}